I know the submission instructions requested two java files, CalendarProgram.java and CalendarProgramMain.java

However the instructions specified that I call the class CalendarManager, and the CalendarProgramMain functionality required the Appointment class to be public

So I submitted three java files:
1. CalendarManager.java with the CalendarManager class and the Node class
1. Appointment.java with the Appointment class
1. CalendarProgramMain.java with the testing

Thank you
