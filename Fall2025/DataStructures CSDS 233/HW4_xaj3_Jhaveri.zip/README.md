Hi,

All of my code and testing is contained within the 'WordQuest.java' file

The output doesn't match the sample code exactly:
- There is a rehash in sample 2 which carried over from sample 1
- There is no rehash in sample 3 because the load factor didn't exceed 0.6
But I'm almost certain that everything functions as intended

Thank you
