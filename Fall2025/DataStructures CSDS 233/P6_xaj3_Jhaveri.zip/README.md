Hello. I figured that it was easier for both of us to simply put all of the unit tests directly in the main method.
You can run the tests by simply running the java file.

Sorry for any confusion, thank you
